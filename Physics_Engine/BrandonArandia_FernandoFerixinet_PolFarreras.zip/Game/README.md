# Physics_2_Physics_Engine
A simple physics engine I made during the Physics 2 subject - Second year of videogame development

The main objective of the ga me is to kill al the penguins using your wapons avaiable and before the timer ends!

#Controls

A D - move
Space - shoot
Q E - change direction
N M - chhange weapons
Z - return to spawn point

F1 - view colliders
T - free camera within game bounds (userful for aiming)

All controls are shown in game;
